﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace DataGridConfiguration
{
    public class Commands:ICommand
    {
        private Action<object> DoWork;
        private Predicate<object> _canExecute;
        public Commands(Action<object> work, Predicate<object> canExecute)
        {
            DoWork = work;
            _canExecute = canExecute;
        }
        public Commands(Action<object> work)
        {
            DoWork = work;
        }

        public event EventHandler CanExecuteChanged
        {
            add
            {
                if (_canExecute != null)
                {
                    CommandManager.RequerySuggested += value;
                }
            }
            remove
            {
                if (_canExecute != null)
                {
                    CommandManager.RequerySuggested -= value;
                }
            }
        }
        public bool CanExecute(object parameter)
        {
            if (_canExecute != null)
                return _canExecute(parameter);
            return true;
        }

        public void Execute(object parameter)
        {
            DoWork(parameter);
        }
    }
}
