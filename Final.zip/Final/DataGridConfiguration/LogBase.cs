﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DataGridConfiguration
{
    public abstract class LogBase
    {
        public abstract void Log(string Message);
    }
}
