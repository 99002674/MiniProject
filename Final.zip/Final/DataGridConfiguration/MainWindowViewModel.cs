﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Xml.Serialization;

namespace DataGridConfiguration
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        ListOfStudents Data;
        MainWindowModel Model = new MainWindowModel();

        private List<DataGridContent> student;

        public List<DataGridContent> Student
        {
            get { return student; }
            set
            {
                student = value;
                OnPropertyChanged("Student");
            }
        }

        private ICommand search;

        public ICommand Search => search ?? (search = new RelayCommand(SearchByName, CanExecute));

        private RelayCommand viewData;

        public RelayCommand ViewData
        {
            get { return viewData; }
        }
        private RelayCommand allData;

        public RelayCommand AllData

        {
            get { return allData; }
        }
        private string searchText;

        public string SearchText
        {
            get { return searchText; }
            set
            {
                searchText = value;
                OnPropertyChanged("SearchText");
                Search.CanExecute(null);
            }
        }

        private ObservableCollection<string> displayList;

        public ObservableCollection<string> DisplayList
        {
            get { return displayList; }
            set
            { 
                displayList = value;
                OnPropertyChanged("DisplayList");
                
            }
        }

        private ObservableCollection<string> listBoxView;

        public ObservableCollection<string> ListBoxView
        {
            get { return listBoxView; }
            set
            {
                listBoxView = value;
                OnPropertyChanged("ListBoxView");
            }
        }

        public MainWindowViewModel()
        {
            Data = Model.Deserialzation();
            Student = Data.Pupils;
            viewData = new RelayCommand(ViewSelectedData, null);
            allData = new RelayCommand(ListOfAllData, null);
        }

        private bool ShowSelectedData(object obj)
        {
            int flag = 0;
            foreach (DataGridContent dgc in Student)
            {
                if (dgc.IsSelected == true)
                {
                    flag = 1;
                }
            }
            if (flag == 0)
            {
                return false;
            }
            return true;
        }

        private bool CanExecute(object obj)
        {
            if (searchText == "" || searchText == null)
                return false;
            return true;
        }
        public void ListOfAllData(object obj)
        {
            //DisplayList.Clear();
            this.DisplayList = Model.DisplayAllData(Student);
        }
        public void ViewSelectedData(object obj)
        {
            //DisplayList.Clear();
            this.DisplayList = Model.DisplaySelectedData(Student);
        }
       public void  SearchByName(object obj)
        {
            ListBoxView objectlbv = new ListBoxView(this);
            objectlbv.ShowDialog();
            this.ListBoxView = Model.DisplaySearchedData(Student, SearchText);
            //this.DisplayList = Model.DisplaySearchedData(Student, SearchText);

        }
        public void DataDeserialization()
        {
            Data = Model.Deserialzation();
            this.Student = Data.Pupils;
        }
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }
	public class DataGridContent
	{
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private string birthday;

        public string Birthday
        {
            get { return birthday; }
            set { birthday = value; }
        }

        private  string gender;

        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        private bool isSelected;

        public bool IsSelected
        {
            get { return isSelected; }
            set
            {
                isSelected = value;
                
            }
        }
    }
    public class ListOfStudents
	{
        private List<DataGridContent> pupils;

        public List<DataGridContent> Pupils
        {
            get { return pupils; }
            set { pupils = value; }
        }
    }
}
