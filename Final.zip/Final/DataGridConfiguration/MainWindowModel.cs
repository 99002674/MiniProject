﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Windows.Controls;

namespace DataGridConfiguration
{
    public class MainWindowModel
    {
        Logger logger = new Logger();
        ObservableCollection<string> Message = new ObservableCollection<string>();
       
        public ListOfStudents Deserialzation()
        {
            logger.Log("Deserialization");
            ListOfStudents s;
            try
            {
                XmlSerializer sl = new XmlSerializer(typeof(ListOfStudents));
                string FilePath = "StudentData.xml";
                FileStream fs = new FileStream(FilePath, FileMode.Open, FileAccess.Read);
                logger.Log("Opening the file and reading the data");
                s = (ListOfStudents)sl.Deserialize(fs);
                //Student.ItemsSource = s;
                fs.Flush();
                fs.Close();
                logger.Log("Closing the file");
                return s;
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show("File doesn't exist");
                logger.Log("File doesn't exist in the givin location: "+ ex.ToString());
            }
            return null;
        }

        public ObservableCollection<string> DisplayAllData(List<DataGridContent> dataGrid)
        {
            logger.Log("Display all data");
            Message.Clear();
            try
            {
                foreach(DataGridContent dgc in dataGrid)
                {
                    string Note = $"Name: { dgc.Name}, DOB: {dgc.Birthday}, Gender: {dgc.Gender}";
                    Message.Add(Note);
                }
                logger.Log("Added all data from datagrid to list");
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
            return Message;
        }
        public ObservableCollection<string> DisplaySelectedData(List<DataGridContent> dataGrid)
        {
            logger.Log("Display Selected data");
            Message.Clear();
            try
            {
                foreach (DataGridContent dgc in dataGrid)
                {
                    if (dgc.IsSelected == true)
                    {
                        string Note = $"Name: { dgc.Name}, DOB: {dgc.Birthday}, Gender: {dgc.Gender}";
                        Message.Add(Note);
                    }
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
            return Message;
        }
        public ObservableCollection<string> DisplaySearchedData(List<DataGridContent> dataGrid, string searchData)
        {
            logger.Log("Display search data");
            Message.Clear();

            try
            {
                if (searchData != "" && searchData != null)
                {
                    string SearchData = searchData.ToLower();
                    string DGName, DGBirthday;
                    int flag = 0;
                    foreach (DataGridContent dgc in dataGrid)
                    {
                        DGName = dgc.Name.ToLower();
                        DGBirthday = dgc.Birthday;
                        bool CheckName = DGName.Contains(SearchData);
                        bool CheckBirthday = DGBirthday.Contains(SearchData);

                        if (CheckName || CheckBirthday)
                        {
                            string Note = $"Name: { dgc.Name}, DOB: {dgc.Birthday}, Gender: {dgc.Gender}"; 
                            Message.Add(Note);
                            flag = 1;
                        }
                    }
                    if (flag == 0)
                    {
                        System.Windows.MessageBox.Show("No Match Found");
                    }
                }
                else
                {
                    System.Windows.MessageBox.Show("Enter the name to be searched!!!");
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
            return Message;
        }
    }
}
