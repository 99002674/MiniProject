﻿using DataGridConfiguration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace UnitTest
{
    [TestFixture]
    public class UnitTest1
    {
        [Test]
        public void DisplayListTest()
        {
            var mainWindowViewModel = new MainWindowViewModel();
            var AllData = new List<string>();

            //AllData.Add("Name: Harini, DOB: 09-11-1998, Gender: Female");
            //AllData.Add("Name: Anjali, DOB: 20-02-1999, Gender: Female");
            //AllData.Add("Name: Binitta, DOB: 24-11-1998, Gender: Female");


            mainWindowViewModel.ListOfAllData(null);

            NUnit.Framework.Assert.AreEqual(AllData, mainWindowViewModel.DisplayList);    
        }
        [Test]
        public void DisplaySelectedDataTest()
        {
            var mainWindowViewModel = new MainWindowViewModel();
            var AllData = new List<string>();

            AllData.Add("Name: Harini, DOB: 09-11-1998, Gender: Female");
            mainWindowViewModel.ViewSelectedData(null);
            NUnit.Framework.Assert.AreEqual(AllData, mainWindowViewModel.DisplayList);
        }
        [Test]
        public void SearchTextTest()
        {
            var mainWindowViewModel = new MainWindowViewModel();
            var AllData = new List<string>();

            AllData.Add("Name: Harini, DOB: 09-11-1998, Gender: Female");
            mainWindowViewModel.SearchText = "harini";
            mainWindowViewModel.SearchByName(null);
            NUnit.Framework.Assert.AreEqual(AllData, mainWindowViewModel.ListBoxView);
        }
    }
}